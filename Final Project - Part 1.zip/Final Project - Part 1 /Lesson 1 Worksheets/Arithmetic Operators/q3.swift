import Foundation

let jump1 = 3.3
let jump2 = 4.0
let jump3 = 3.0

let average = (jump1 + jump2 + jump3) / 3
print("The average jump length is \(average) m")