import Foundation

let radius = 15.0
let pi = 3.14
let circumference = 2 * pi * radius
print(circumference)  