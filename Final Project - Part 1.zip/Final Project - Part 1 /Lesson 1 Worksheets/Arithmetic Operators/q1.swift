import Foundation

print(2 * 3)                 
print(2 + 3 * 5)              
print((2 + 13) / 5)          
print(pow(2.0, 5.0))          
print((7.0 / 3.0) - 1)        
print((7 - 12) / (6 - 1))     