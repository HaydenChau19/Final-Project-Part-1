import Foundation

print("Number Systems")
print("Convert to Base 10")
print("This program converts a number from another base to base 10.\n")

print("Enter the base: ", terminator: "")
let base = Int(readLine()!) ?? 10

print("Enter the number: ", terminator: "")
let number = readLine() ?? "0"

if let result = Int(number, radix: base) {
    print("The number in base 10 is \(result).")
} else {
    print("Invalid input for base \(base).")
}