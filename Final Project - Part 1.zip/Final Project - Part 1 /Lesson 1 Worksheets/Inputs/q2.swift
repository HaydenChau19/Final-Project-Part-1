import Foundation

print("Enter the first score: ", terminator: "")
let score1 = Double(readLine()!) ?? 0.0

print("Enter the second score: ", terminator: "")
let score2 = Double(readLine()!) ?? 0.0

print("Enter the third score: ", terminator: "")
let score3 = Double(readLine()!) ?? 0.0

print("Enter the player's name: ", terminator: "")
let name = readLine() ?? "Player"

let average = (score1 + score2 + score3) / 3

print("\(name) scored an average of \(average) goals per game.")