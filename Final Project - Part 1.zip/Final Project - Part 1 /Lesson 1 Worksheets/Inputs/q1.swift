import Foundation

print("Enter the first number: ", terminator: "")
let num1 = Int(readLine()!) ?? 0

print("Enter the second number: ", terminator: "")
let num2 = Int(readLine()!) ?? 0

let sum = num1 + num2
let diff = num2 - num1

print("The sum is \(sum).")
print("The difference is \(diff).")