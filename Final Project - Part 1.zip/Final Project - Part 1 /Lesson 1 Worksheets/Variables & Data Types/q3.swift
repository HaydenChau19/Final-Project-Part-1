import Foundation

var favoriteAnimal = "dolphin"
var animalTrait = "intelligent"

print("My favourite animal is the \(favoriteAnimal) because they are \(animalTrait).")

favoriteAnimal = "tiger"
animalTrait = "strong"

print("My favourite animal is the \(favoriteAnimal) because they are \(animalTrait).")