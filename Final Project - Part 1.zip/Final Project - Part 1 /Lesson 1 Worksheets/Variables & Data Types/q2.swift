import Foundation

let salesTaxRate = 0.13 

func calculateTotalPrice(price: Double) -> Double {
    let salesTax = price * salesTaxRate
    let totalPrice = price + salesTax
    return totalPrice
}

let price1 = 5.0
let price2 = 25.0

let totalPrice1 = calculateTotalPrice(price: price1)
let totalPrice2 = calculateTotalPrice(price: price2)

print("The total price for a purchase of $\(price1) is $\(totalPrice1)")
print("The total price for a purchase of $\(price2) is $\(totalPrice2)")