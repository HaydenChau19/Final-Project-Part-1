import Foundation

print("Enter 'A' to calculate the area of a rectangle or 'V' to calculate the volume of a rectangular prism: ", terminator: "")
if let choice = readLine()?.uppercased() {
    if choice == "A" {
        print("Enter the length: ", terminator: "")
        let length = Double(readLine()!) ?? 0.0
        print("Enter the width: ", terminator: "")
        let width = Double(readLine()!) ?? 0.0
        let area = round((length * width) * 100) / 100
        print("The area of the rectangle is \(area)")
    } else if choice == "V" {
        print("Enter the length: ", terminator: "")
        let length = Double(readLine()!) ?? 0.0
        print("Enter the width: ", terminator: "")
        let width = Double(readLine()!) ?? 0.0
        print("Enter the height: ", terminator: "")
        let height = Double(readLine()!) ?? 0.0
        let volume = round((length * width * height) * 100) / 100
        print("The volume of the rectangular prism is \(volume)")
    } else {
        print("Invalid input. Please enter 'A' or 'V'.")
    }
}