import Foundation

print("Enter the number of hours worked in a week: ", terminator: "")
if let hoursInput = readLine(), let hoursWorked = Int(hoursInput), hoursWorked >= 0 {
    print("Enter the hourly rate of pay: ", terminator: "")
    if let payInput = readLine(), let hourlyRate = Double(payInput), hourlyRate > 0 {
        let regularHours = min(hoursWorked, 40)
        let overtimeHours = max(hoursWorked - 40, 0)
        let regularPay = Double(regularHours) * hourlyRate
        let overtimePay = Double(overtimeHours) * hourlyRate * 1.5
        let totalPay = regularPay + overtimePay
        print("The total pay is $\(round(totalPay * 100) / 100)")
    } else {
        print("Invalid hourly rate.")
    }
} else {
    print("Invalid hours input.")
}