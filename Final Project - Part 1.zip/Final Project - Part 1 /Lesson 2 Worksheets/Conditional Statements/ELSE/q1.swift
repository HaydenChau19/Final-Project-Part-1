import Foundation

print("Enter a number (1-99): ", terminator: "")
if let input = readLine(), let number = Int(input), number > 0 && number < 100 {
    if number < 10 {
        print("The number \(number) is one digit.")
    } else {
        print("The number \(number) is two digits.")
    }
} else {
    print("Invalid input.")
}