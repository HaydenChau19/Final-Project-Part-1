import Foundation

print("Enter a letter grade (A, B, C, D, E): ", terminator: "")
if let grade = readLine()?.uppercased() {
    switch grade {
    case "A":
        print("Range: 80 - 100")
    case "B":
        print("Range: 70 - 79")
    case "C":
        print("Range: 60 - 69")
    case "D":
        print("Range: 50 - 59")
    case "E":
        print("Range: 0 - 49")
    default:
        print("Invalid letter grade")
    }
} else {
    print("Invalid input.")
}