import Foundation

var isFrozen2Showing = false 

if isFrozen2Showing {
    print("Frozen II is showing. Buy a ticket!")
} else {
    print("Frozen II is not showing. Leave the theatre.")
}