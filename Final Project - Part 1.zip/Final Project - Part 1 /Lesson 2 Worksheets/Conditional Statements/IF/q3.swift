import Foundation

print("Enter a number: ", terminator: "")
if let input = readLine(), let number = Int(input) {
    print("Checking if \(number) is greater than 10")
    if number > 10 {
        print("Success: \(number) is greater than 10")
    }
    print("Done checking")
} else {
    print("Invalid input. Please enter a number.")
}