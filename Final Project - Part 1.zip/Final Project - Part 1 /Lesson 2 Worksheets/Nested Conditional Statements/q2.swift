import Foundation

print("Enter the weight of the package (kg): ", terminator: "")
if let weightInput = readLine(), let weight = Double(weightInput) {
    
    print("Enter the length of the package (cm): ", terminator: "")
    if let lengthInput = readLine(), let length = Double(lengthInput) {
        
        print("Enter the width of the package (cm): ", terminator: "")
        if let widthInput = readLine(), let width = Double(widthInput) {
            
            print("Enter the height of the package (cm): ", terminator: "")
            if let heightInput = readLine(), let height = Double(heightInput) {
                
                let volume = (length * width * height) / 100000.0
                
                if weight > 27 {
                    if volume > 0.1 {
                        print("Package is too heavy and too large")
                    } else {
                        print("Package is too heavy")
                    }
                } else {
                    if volume > 0.1 {
                        print("Package is too large")
                    } else {
                        print("Package meets requirements")
                    }
                }
                
            } else {
                print("Invalid height input.")
            }
        } else {
            print("Invalid width input.")
        }
    } else {
        print("Invalid length input.")
    }
} else {
    print("Invalid weight input.")
}