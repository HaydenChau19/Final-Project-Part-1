import Foundation

print("Enter the number of copies to print: ", terminator: "")
if let input = readLine(), let copies = Int(input), copies >= 0 {
    print("Are you a Prime user? (yes/no): ", terminator: "")
    let isPrime = readLine()?.lowercased() == "yes"
    
    var pricePerCopy: Double = 0.0

    if copies <= 499 {
        pricePerCopy = 0.30
    } else if copies <= 749 {
        pricePerCopy = 0.28
    } else if copies <= 999 {
        pricePerCopy = 0.27
    } else {
        pricePerCopy = 0.25
    }

    var totalPrice = Double(copies) * pricePerCopy
    
    if isPrime {
        if copies >= 900 {
            totalPrice *= 0.90 
        }
    }
    
    totalPrice = round(totalPrice * 100) / 100
    print("Price per copy: $\(pricePerCopy)")
    print("Total price: $\(totalPrice)")
} else {
    print("Invalid input. Please enter a valid number of copies.")
}