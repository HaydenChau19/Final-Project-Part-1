//Header
//Name: computer_trouble_shooting
//Programmer: Hayden Chau
//Date: Jan 2, 2025
//Description: This program helps users fix their computer if they have any problems relating to the beeping of their computer or the spinning of the drive of their computer.

import Foundation

//Input Statements
print("Does the computer beep on startup? (yes/no): ", terminator: "")
let beeps = readLine()?.lowercased()

print("Does the hard drive spin? (yes/no): ", terminator: "")
let spins = readLine()?.lowercased()

// Processing and Output Statements 
if beeps == "yes" {
    if spins == "yes" {
        print("Contact tech support")
    } else {
        print("Check drive contacts")
    }
} else {
    if spins == "yes" {
        print("Check the speaker connections")
    } else {
        print("Bring computer to repair center")
    }
}