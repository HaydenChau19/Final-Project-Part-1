import Foundation

let programName = "computer_trouble_shooting"
print("Program Name: \(programName)")

print("Does the computer beep on startup? (yes/no): ", terminator: "")
let beeps = readLine()?.lowercased() == "yes"

print("Does the hard drive spin? (yes/no): ", terminator: "")
let spins = readLine()?.lowercased() == "yes"

if beeps && spins {
    print("Contact tech support")
} else if beeps && !spins {
    print("Check drive contacts")
} else if !beeps && !spins {
    print("Bring computer to repair center")
} else if !beeps && spins {
    print("Check the speaker connections")
}