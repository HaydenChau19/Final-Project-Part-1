import Foundation

print("Enter a number between 1 and 100: ", terminator: "")
if let input = readLine(), let number = Int(input), number >= 1 && number <= 100 {
    
    if number % 10 == 0 {
        print("Criteria A")
    } else if (number % 5 == 0 || number < 40) {
        print("Criteria B")
    } else if number < 60 {
        print("Criteria C")
    } else {
        print("Does not match any Criteria")
    }
    
} else {
    print("Invalid input. Please enter a number between 1 and 100.")
}