import Foundation

var userArray = [Int]()

for i in 1...15 {
    print("Enter integer \(i): ", terminator: "")
    if let input = readLine(), let number = Int(input) {
        userArray.append(number)
    }
}

print("Enter the position (1 to 15) to replace from the front: ", terminator: "")
if let positionInput = readLine(), let position = Int(positionInput), position >= 1 && position <= 15 {
    print("Enter the new number: ", terminator: "")
    if let replacementInput = readLine(), let replacement = Int(replacementInput) {
        userArray[position - 1] = replacement 
        print("Updated array: \(userArray)")
    }
}