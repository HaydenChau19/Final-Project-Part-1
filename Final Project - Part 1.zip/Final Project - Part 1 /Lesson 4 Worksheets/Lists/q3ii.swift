import Foundation

var userArray = [Int]()

for i in 1...15 {
    print("Enter integer \(i): ", terminator: "")
    if let input = readLine(), let number = Int(input) {
        userArray.append(number)
    }
}

print("Enter the position (1 to 15) to replace from the back: ", terminator: "")
if let positionInput = readLine(), let position = Int(positionInput), position >= 1 && position <= 15 {
    print("Enter the new number: ", terminator: "")
    if let replacementInput = readLine(), let replacement = Int(replacementInput) {
        let indexFromBack = userArray.count - position
        userArray[indexFromBack] = replacement 
        print("Updated array: \(userArray)")
    }
}