import Foundation

var numbers = [1, 2, 3, 4, 5]

print("Enter a number to replace the middle element: ", terminator: "")
if let input = readLine(), let newMiddle = Int(input) {
    numbers[numbers.count / 2] = newMiddle 
    print("Updated array: \(numbers)")
}