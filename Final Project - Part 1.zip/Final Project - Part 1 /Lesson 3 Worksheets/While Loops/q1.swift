import Foundation

print("Enter the first number (larger number): ", terminator: "")
if let input1 = readLine(), let start = Int(input1) {
    print("Enter the second number (smaller number): ", terminator: "")
    if let input2 = readLine(), let end = Int(input2) {
        var current = start
        while current >= end {
            print(current)
            current -= 1
        }
    } else {
        print("Invalid input for the second number.")
    }
} else {
    print("Invalid input for the first number.")
}