import Foundation

let target = Int.random(in: 1...50)
var guessedCorrectly = false

while !guessedCorrectly {
    print("Guess a number between 1 and 50: ", terminator: "")
    if let input = readLine(), let guess = Int(input) {
        if guess > target {
            print("Too high")
        } else if guess < target {
            print("Too low")
        } else {
            print("You guessed correctly!")
            guessedCorrectly = true
        }
    }
}