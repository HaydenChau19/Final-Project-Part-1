import Foundation

var sum = 0
var count = 0

while true {
    print("Enter number (enter 0 to stop): ", terminator: "")
    if let input = readLine(), let number = Int(input) {
        if number == 0 {
            break
        }
        sum += number
        count += 1
    }
}

if count > 0 {
    let average = Double(sum) / Double(count)  
    print("The average is \(average)")
} else {
    print("No numbers were entered.")
}