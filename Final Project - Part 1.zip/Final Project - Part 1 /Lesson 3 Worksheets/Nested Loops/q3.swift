import Foundation

let targetSums = [3, 4, 12]

for target in targetSums {
    var count = 0
    print("Ways to add up to \(target):")
    for die1 in 1...6 {
        for die2 in 1...6 {
            if die1 + die2 == target {
                print("(\(die1), \(die2))")
                count += 1
            }
        }
    }
    print("Total ways: \(count)\n")
}