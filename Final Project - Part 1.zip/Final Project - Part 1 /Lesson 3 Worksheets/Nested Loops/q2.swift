import Foundation

print("Enter the horizontal measure: ", terminator: "")
if let input1 = readLine(), let horizontal = Int(input1) {
    print("Enter the vertical measure: ", terminator: "")
    if let input2 = readLine(), let vertical = Int(input2) {
        for _ in 1...vertical {
            for _ in 1...horizontal {
                print("*", terminator: "")
            }
            print()
        }
    } else {
        print("Invalid input for vertical measure.")
    }
} else {
    print("Invalid input for horizontal measure.")
}