import Foundation

for i in 1...5 {
    print("Omar \(i)")
    for j in 1...3 {
        print("Hayden \(j)")
    }
}