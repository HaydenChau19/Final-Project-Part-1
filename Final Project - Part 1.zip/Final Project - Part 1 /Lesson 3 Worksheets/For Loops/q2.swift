import Foundation

var product = 1

for i in 1...4 {
    print("Enter number \(i): ", terminator: "")
    if let input = readLine(), let number = Int(input) {
        product *= number
    } else {
        print("Invalid input.")
        break
    }
}
print("The product of the numbers is: \(product)")