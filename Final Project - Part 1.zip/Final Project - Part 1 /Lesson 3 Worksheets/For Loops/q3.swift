import Foundation

for i in 1..<20 where i % 2 != 0 {
    print(i)
}