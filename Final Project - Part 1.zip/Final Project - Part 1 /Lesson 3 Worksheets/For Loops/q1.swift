import Foundation

print("Enter the starting number: ", terminator: "")
if let input = readLine(), let start = Int(input) {
    var result = start
    for _ in 1...3 {
        result -= 20
    }
    print("Result after subtracting 20 three times: \(result)")
} else {
    print("Invalid input.")
}