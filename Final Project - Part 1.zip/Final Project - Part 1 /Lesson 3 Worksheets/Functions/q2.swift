import Foundation

func isInRange(number: Int, lower: Int, upper: Int) -> Bool {
    return number >= lower && number <= upper
}

print("Enter a number: ", terminator: "")
if let numInput = readLine(), let num = Int(numInput) {
    print("Enter the lower bound: ", terminator: "")
    if let lowerInput = readLine(), let lower = Int(lowerInput) {
        print("Enter the upper bound: ", terminator: "")
        if let upperInput = readLine(), let upper = Int(upperInput) {
            print(isInRange(number: num, lower: lower, upper: upper) ? 
                  "\(num) is in range." : 
                  "\(num) is not in range.")
        }
    }
}