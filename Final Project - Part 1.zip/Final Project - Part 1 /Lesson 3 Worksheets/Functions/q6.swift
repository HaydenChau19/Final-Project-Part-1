import Foundation

func getCost(for code: Character) -> Float {
    switch code {
    case "I": return 1.50
    case "S": return 3.50
    case "T": return 5.50
    case "W": return 12.50
    default: return 0.00
    }
}

print("Enter a code (I, S, T, W): ", terminator: "")
if let codeInput = readLine(), let code = codeInput.first {
    let cost = getCost(for: code)
    if cost > 0 {
        print("The cost for code \(code) is \(cost).")
    } else {
        print("Invalid code entered.")
    }
}