func drawTriangle(n: Int, char: Character, flag: Bool) {
    if flag {
        for i in 1...n {
            print(String(repeating: char, count: i))
        }
    } 
    else {
        let start = (n + 1) / 2 
        for i in start...n {
            print(String(repeating: char, count: i))
        }
    }
}

print("Enter the size of the triangle (n): ", terminator: "")
if let nInput = readLine(), let n = Int(nInput) {
    print("Enter the character to use for the triangle: ", terminator: "")
    if let charInput = readLine(), let char = charInput.first {
        print("Enter True or False for the flag: ", terminator: "")
        if let flagInput = readLine(), let flag = Bool(flagInput) {
            drawTriangle(n: n, char: char, flag: flag)
        }
    }
}

print("\nChristmas Tree (4 layers):")
for layer in 1...4 {
    let size = 2 + layer 
    drawTriangle(n: size, char: "*", flag: true)
}