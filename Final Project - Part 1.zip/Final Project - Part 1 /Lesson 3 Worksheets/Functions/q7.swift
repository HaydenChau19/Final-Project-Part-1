import Foundation

func centrifugalForce(m: Double, r: Double, v: Double) -> Double {
    let omega = 2 * Double.pi * (v / 60) 
    return m * r * omega * omega
}

print("Enter mass (kg): ", terminator: "")
if let massInput = readLine(), let mass = Double(massInput) {
    print("Enter angular velocity (rpm): ", terminator: "")
    if let velocityInput = readLine(), let velocity = Double(velocityInput) {
        print("Centrifugal forces at radii from 10m to 100m:")
        for radius in stride(from: 10.0, through: 100.0, by: 5.0) {
            let force = centrifugalForce(m: mass, r: radius, v: velocity)
            print("Radius: \(radius)m -> Force: \(force)N")
        }
    }
}