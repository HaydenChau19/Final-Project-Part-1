import Foundation

func repeatPhrase(_ phrase: String, times: Int) {
    for _ in 1...times {
        print(phrase)
    }
}

print("Enter a phrase: ", terminator: "")
if let phrase = readLine() {
    print("Enter the number of times to repeat: ", terminator: "")
    if let timesInput = readLine(), let times = Int(timesInput) {
        repeatPhrase(phrase, times: times)
    }
}