import Foundation

func swapHalves(of str: String) -> String {
    let mid = str.count / 2
    let index = str.index(str.startIndex, offsetBy: mid + (str.count % 2))
    let firstHalf = String(str[..<index]) 
    let secondHalf = String(str[index...]) 
    return secondHalf + firstHalf
}

print("Enter a string to swap its halves: ", terminator: "")
if let input = readLine() {
    print("Swapped halves: \(swapHalves(of: input))")
}