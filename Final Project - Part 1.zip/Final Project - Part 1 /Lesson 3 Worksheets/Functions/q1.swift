import Foundation

func findMax(of a: Int, _ b: Int, _ c: Int) -> Int {
    return max(a, max(b, c))
}

print("Enter the first number: ", terminator: "")
if let n1 = readLine(), let num1 = Int(n1) {
    print("Enter the second number: ", terminator: "")
    if let n2 = readLine(), let num2 = Int(n2) {
        print("Enter the third number: ", terminator: "")
        if let n3 = readLine(), let num3 = Int(n3) {
            let maxNum = findMax(of: num1, num2, num3)
            print("The maximum is \(maxNum).")
        }
    }
}